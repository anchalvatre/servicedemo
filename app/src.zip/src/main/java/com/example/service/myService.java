package com.example.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class myService extends Service {
  String text;
  @Override
  public IBinder onBind(Intent intent) {
    return null;
  }

  @Override
  public int onStartCommand(Intent intent, int flags, int startId) {
    Toast.makeText(this, "service started", Toast.LENGTH_SHORT).show();
    text = (String) intent.getExtras().get("text");
    Log.d(getApplicationContext().toString(), "onStartCommand: dfjls");
    return START_STICKY;
  }

  @Override
  public void onDestroy() {
    super.onDestroy();
    Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    Log.d(getApplicationContext().toString(),"ldkfjdk");
  }
}
